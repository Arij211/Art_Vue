package services.utilisateur;

public interface UtilisateurService {
}
