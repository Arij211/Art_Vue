package services.oeuvreArt;

public class OeuvreArt {
}
