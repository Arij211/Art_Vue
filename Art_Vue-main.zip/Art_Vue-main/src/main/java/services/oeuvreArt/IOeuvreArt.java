package services.oeuvreArt;

public interface IOeuvreArt {
}
