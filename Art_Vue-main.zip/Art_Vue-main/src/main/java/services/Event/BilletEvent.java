package services.Event;

import java.sql.SQLException;
import java.util.List;

public interface BilletEvent<T>{
    void ajouterbillet(T t) throws SQLException;
    void modifierbillet(T t) throws SQLException;
    void supprimerbillet(int id) throws SQLException;
    List<T> recupererebillet() throws SQLException;
}
